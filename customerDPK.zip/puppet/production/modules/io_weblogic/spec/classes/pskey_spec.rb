require 'spec_helper'

describe('io_weblogic::pskey', :type => :class) do
end
